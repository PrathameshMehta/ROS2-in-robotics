# Minimal action client cookbook recipes

This package contains a few examples that show how to create action clients.
