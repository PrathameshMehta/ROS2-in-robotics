import rclpy
from rclpy.node import Node
import math as m
from std_msgs.msg import Float32MultiArray

def quarternion_conversion(e):
    quarternion_x, quarternion_y, quarternion_z, quarternion_w = 0,0,0,0

    cos_yaw = m.cos(e[2] * 0.5)
    sin_yaw = m.sin(e[2] * 0.5)
    cos_pitch = m.cos(e[1] * 0.5)
    sin_pitch = m.sin(e[1] * 0.5)
    cos_roll = m.cos(e[0] * 0.5)
    sin_roll = m.sin(e[0] * 0.5)

    quarternion_w = cos_roll * cos_pitch * cos_yaw + sin_roll * sin_pitch * sin_yaw
    quarternion_x = sin_roll * cos_pitch * cos_yaw - cos_roll * sin_pitch * sin_yaw
    quarternion_y = cos_roll * sin_pitch * cos_yaw + sin_roll * cos_pitch * sin_yaw
    quarternion_z = cos_roll * cos_pitch * sin_yaw - sin_roll * sin_pitch * cos_yaw

    return quarternion_w, quarternion_x, quarternion_y, quarternion_z

class QuaternionSubs(Node):

    def __init__(self):
        super().__init__('quaternion_subs')
        self.subscription = self.create_subscription(
            Float32MultiArray,
            'topic',
            self.listener_callback,
            10)
        self.subscription

    def listener_callback(self, msg):
        q_w, q_x, q_y, q_z = quarternion_conversion(msg.data)
        self.get_logger().info('x: %f,\t y: %f,\t z: %f,\t w: %f' % (q_x, q_y, q_z, q_w))
        
def main(args=None):
    rclpy.init(args=args)

    quaternion_subscriber = QuaternionSubs()

    rclpy.spin(quaternion_subscriber)

    quaternion_subscriber.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
